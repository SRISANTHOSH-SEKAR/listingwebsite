let suggestions = [

    "Hotel Deepam",
    "Hotel Rockfort Veiw",
    "Sri Maharaja Residency",
    "Ramyas Hotel",
    "Suraj Residency",
    "Vivid a Boutique Hotel",
    "Grade inn Trichy",
    "Hotel Apple Park inn",
    "KVM Hotels Srirangam",
    "The scarlet Srirangam",
    "Plaza Hotel Trichy",
    "Grand Gardenia",
    "Breeze Residency",
    "Maya Residency"
];